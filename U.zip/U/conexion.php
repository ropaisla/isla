<?php
function conectar(){
    $host="152.67.231.40";
    $user="root";
    $pass="";

    $bd="1";

    $con=mysqli_connect($host,$user,$pass);

    mysqli_select_db($con,$bd);

    return $con;
}
?>
